#!/bin/bash

#$ -pe smp 12         # Specify parallel environment and legal core size
#$ -q long            # Run on the GPU cluster 
#$ -N SPCBoltz204       # Specify job name

module load cp2k
    
mpirun -np $NSLOTS cp2k.popt -o output_traj_203.out -i traj_0_modified.inp
