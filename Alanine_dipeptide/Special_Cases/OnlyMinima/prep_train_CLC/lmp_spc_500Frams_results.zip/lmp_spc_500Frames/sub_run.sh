#!/bin/bash

#$ -pe smp 24     # Specify parallel environment and legal core size
#$ -q long ##hpc@@colon    # Specify queue
#$ -N select       # Specify job name

module load lammps     # Required modules

#python selected_phi_psi.py  # Application to execute
#python lmp_spc_prep.py  # Application to execute 
#python initial_configs.py 224 -3.14 3.14 224 -3.14 3.14 --plot

python test-run.py  # Application to execute
