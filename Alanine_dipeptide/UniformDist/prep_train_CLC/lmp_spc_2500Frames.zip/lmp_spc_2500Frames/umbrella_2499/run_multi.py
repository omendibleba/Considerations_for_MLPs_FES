import numpy as np
import matplotlib.pyplot as plt
import os
import subprocess
import natsort
from multiprocessing import Pool

# Define a function to run the lammps simulation for a folder
def run_simulation(folder):
    print(f'Running the lammps simulation for the folder {folder}\n', end='\r')
    os.chdir(folder)

    # Input file is the file that ends with .inp
    input_file = [file for file in os.listdir(f'./') if file.endswith('.inp')][0]
    print(input_file + '\n')

    # Run the lammps simulations
    os.system(f'lmp -in {input_file} ')
    
    os.chdir('../')

if __name__ == '__main__':
    # Get a list of folders to process
    folders = [folder for folder in natsort.natsorted(os.listdir('./')) if folder.startswith('umbrella_')]

    # Define the number of processors to use (4 in this case)
    num_processors = 24

    # Use a Pool of workers to process the folders concurrently
    with Pool(processes=num_processors) as pool:
        pool.map(run_simulation, folders)
