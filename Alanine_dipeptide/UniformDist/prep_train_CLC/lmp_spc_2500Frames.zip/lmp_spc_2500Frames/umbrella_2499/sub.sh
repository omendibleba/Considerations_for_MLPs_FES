#!/bin/bash

#$ -pe smp 24     # Specify parallel environment and legal core size
#$ -q long           # Specify queue
#$ -N rerun       # Specify job name

#conda activate nequip
module load lammps #gsl cmake cuda/11.0 cudnn/8.0.4 ompi/4.0.1/gcc/8.5.0 gcc/11.2.0

#module load python
#python initial_configs.py 50 -3.14 3.14 50 -3.14 3.14

#echo 'Hello World'
#python -m run_cv_config_select_1.py

python run_multi.py
